CREATE PROCEDURE AShowPeopleInCity
    @CityName NVARCHAR(100)
AS
BEGIN

    SELECT *
    FROM Employees
    WHERE City = @CityName;
END;
go

