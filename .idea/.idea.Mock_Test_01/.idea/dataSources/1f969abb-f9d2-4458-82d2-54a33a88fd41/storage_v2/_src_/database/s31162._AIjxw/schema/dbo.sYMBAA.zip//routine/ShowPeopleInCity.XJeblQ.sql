CREATE PROCEDURE ShowPeopleInCity
    @CityName NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT *
    FROM Employees
    WHERE City = @CityName;
END;
go

