CREATE TRIGGER validateTeacherSalary
ON DTeachers
INSTEAD OF UPDATE
AS
BEGIN
    -- declaring only the columns we need to validate
    DECLARE @TeacherID INT, @Salary INT;

    -- Cursor to process rows from the `INSERTED` table
    DECLARE cur CURSOR FOR
    SELECT TeacherID, Salary
    FROM INSERTED;

    OPEN cur;

    FETCH NEXT FROM cur INTO @TeacherID, @Salary;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Salary < 3000
        BEGIN
            SET @Salary = 3000;
        END
        IF @Salary > 5000
        BEGIN
            SET @Salary = 5000;
        END

        -- Update only the salary in the DTeachers table
        UPDATE DTeachers
        SET Salary = @Salary
        WHERE TeacherID = @TeacherID;

        -- Fetch the next record
        FETCH NEXT FROM cur INTO @TeacherID, @Salary;
    END;

    CLOSE cur;
    DEALLOCATE cur;
END;
go

