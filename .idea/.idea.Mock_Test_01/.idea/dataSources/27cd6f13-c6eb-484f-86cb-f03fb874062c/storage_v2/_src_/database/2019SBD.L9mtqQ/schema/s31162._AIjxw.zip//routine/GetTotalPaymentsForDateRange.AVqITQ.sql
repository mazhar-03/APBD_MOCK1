CREATE PROCEDURE GetTotalPaymentsForDateRange
    @StartDate DATE,
    @EndDate DATE,
    @TotalPayments INT OUTPUT
AS
BEGIN
    -- Calculate total payments within the date range
    SELECT @TotalPayments = SUM(P.Amount)
    FROM DPayments P
    WHERE P.PaymentDate BETWEEN @StartDate AND @EndDate;

    -- Handle cases with no payments
    IF @TotalPayments IS NULL
        SET @TotalPayments = 0;
END;
go

