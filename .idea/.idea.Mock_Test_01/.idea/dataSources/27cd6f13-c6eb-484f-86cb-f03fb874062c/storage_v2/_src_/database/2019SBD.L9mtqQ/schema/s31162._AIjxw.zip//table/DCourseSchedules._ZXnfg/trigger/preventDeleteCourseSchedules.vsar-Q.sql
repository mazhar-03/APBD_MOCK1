CREATE TRIGGER preventDeleteCourseSchedules
ON DCourseSchedules
INSTEAD OF DELETE
AS
BEGIN
    DECLARE @ScheduleID INT, @CourseID INT, @StartTime DATE, @EndTime DATE;

    -- Cursor to iterate over rows being attempted for deletion
    DECLARE cur CURSOR FOR
    SELECT ScheduleID, CourseID, StartTime, EndTime FROM DCourseSchedules
    WHERE ScheduleID IN (SELECT ScheduleID FROM DELETED);

    OPEN cur;
    FETCH NEXT FROM cur INTO @ScheduleID, @CourseID, @StartTime, @EndTime;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Check if the course has not started yet
        IF @StartTime > GETDATE()
        BEGIN
            PRINT 'Deleting ScheduleID=' + CAST(@ScheduleID AS VARCHAR) +
                  ' for CourseID=' + CAST(@CourseID AS VARCHAR) + ' because the course has not started yet.';
            DELETE FROM DCourseSchedules WHERE ScheduleID = @ScheduleID; -- Proceed with deletion for this schedule
        END
        ELSE IF @EndTime < GETDATE() -- Check if the course has already finished
        BEGIN
            PRINT 'Deleting ScheduleID=' + CAST(@ScheduleID AS VARCHAR) +
                  ' for CourseID=' + CAST(@CourseID AS VARCHAR) + ' because the course has already finished.';
            DELETE FROM DCourseSchedules WHERE ScheduleID = @ScheduleID; -- Proceed with deletion for this schedule
        END
        ELSE -- Course is ongoing
        BEGIN
            PRINT 'Cannot delete ScheduleID=' + CAST(@ScheduleID AS VARCHAR) +
                  ' for CourseID=' + CAST(@CourseID AS VARCHAR) + ' because the course is ongoing.';
        END;

        -- Fetch the next record
        FETCH NEXT FROM cur INTO @ScheduleID, @CourseID, @StartTime, @EndTime;
    END;

    CLOSE cur;
    DEALLOCATE cur;
END;
go

