CREATE PROCEDURE sp_CheckAttendanceAndCount
    @AttendanceDate DATE,
    @TotalStudents INT OUTPUT
AS
BEGIN
    -- Calculate the number of students marked as present
    SELECT @TotalStudents = COUNT(*)
    FROM DAttendance
    WHERE dDate = @AttendanceDate AND Status = 'Present';

    -- Return 1 if at least one student is present, otherwise return 0
    IF @TotalStudents > 0
        RETURN 1; -- Students are present
    ELSE
        RETURN 0; -- No students are present
END;
go

