CREATE PROCEDURE sp_GetStudentsWithOngoingCourses
AS
BEGIN
    SELECT DISTINCT
        S.StudentID,
        S.FirstName,
        S.LastName,
        E.CourseID,
        C.StartTime,
        C.EndTime
    FROM DStudents S
    INNER JOIN DEnrollments E ON S.StudentID = E.StudentID
    INNER JOIN DCourseSchedules C ON E.CourseID = C.CourseID
    WHERE C.StartTime <= GETDATE() AND C.EndTime >= GETDATE();
END;
go

